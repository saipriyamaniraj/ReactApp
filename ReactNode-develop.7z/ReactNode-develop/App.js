import React, { Component } from 'react';
import { BrowserRouter as Router, Route, Switch, Link } from "react-router-dom";
import Routers from './Routers';
import NormalLoginForm from './NormalLoginForm';
//import './App.css';
class App extends Component{
   render(){
      return(
            <Router>
               <Routers/>
            </Router>
      );
   }
}
export default App;