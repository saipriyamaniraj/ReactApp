import React from 'react';
import NormalLoginForm from './NormalLoginForm';
import EditableTable from './EditableTable';
import { BrowserRouter as Router, Route, Switch, Link } from "react-router-dom";


class Routers extends React.Component{
render(){
    return(
            <Switch>
        <Route path="/" component={NormalLoginForm} />
        <Route path="/login"  component={EditableTable} />
</Switch>
    );
}
}
export default Routers;