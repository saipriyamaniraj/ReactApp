import Immutable, { List as immutableList } from 'immutable';
import { combineReducers } from 'redux-immutable';
import * as ActionTypes from './actionTypes';



function saveDisplayDetails(state = immutableList(), action) {
  switch (action.type) {
    case ActionTypes.RECEIVE_SAVE_CATEGORY:
      return Immutable.fromJS(action.data);
    default:
      return state;
  }
}



export default combineReducers({
 
  saveDisplayDetails
});
